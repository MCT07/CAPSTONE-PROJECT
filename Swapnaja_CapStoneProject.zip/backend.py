import os

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from openai import AzureOpenAI
from pydantic import BaseModel

from orchestrator import executor_agent, governance_agent

load_dotenv()

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

endpoint = os.getenv("endpoint", "").strip()
key = os.getenv("key", "").strip()
deployment = os.getenv("deployment", "chat-model")

client = None
if endpoint and key:
    client = AzureOpenAI(
        api_version="2024-12-01-preview",
        azure_endpoint=endpoint,
        api_key=key,
    )


class ChatRequest(BaseModel):
    message: str


@app.post("/chat")
def chat(request: ChatRequest):
    retrieved_context = executor_agent(request.message)

    context = "\n".join(
        retrieved_context
        if isinstance(retrieved_context, list)
        else [retrieved_context]
    )

    if client is None:
        return {"response": "Backend is not configured with Azure OpenAI credentials."}

    try:
        response = client.chat.completions.create(
            model=deployment,
            messages=[
                {
                    "role": "system",
                    "content": "Answer only using provided context.",
                },
                {
                    "role": "user",
                    "content": f"Context:\n{context}\n\nQuestion:\n{request.message}",
                },
            ],
            max_completion_tokens=300,
        )
        answer = response.choices[0].message.content or ""
    except Exception as exc:
        return {"response": f"Unable to generate response: {exc}"}

    final_answer = governance_agent(answer)

    return {"response": final_answer}
