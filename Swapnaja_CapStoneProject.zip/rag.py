import os

import requests
from dotenv import load_dotenv

load_dotenv()

search_endpoint = os.getenv("search_endpoint", "").strip()
search_key = os.getenv("search_key", "").strip()
index_name = os.getenv("index_name", "").strip()


def search_documents(query):
    if not all([search_endpoint, search_key, index_name]):
        return []

    url = f"{search_endpoint}/indexes/{index_name}/docs/search?api-version=2024-07-01-Preview"

    headers = {
        "Content-Type": "application/json",
        "api-key": search_key,
    }

    data = {
        "search": query,
        "top": 3,
    }

    try:
        response = requests.post(url, headers=headers, json=data, timeout=20)
        response.raise_for_status()
        results = response.json()
    except Exception:
        return []

    if "value" not in results:
        return []

    return [doc.get("chunk", "") for doc in results["value"]]