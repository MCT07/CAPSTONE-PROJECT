from rag import search_documents
from governance import validate_output, guardrails_check

shared_memory = []


def planner_agent(query):
    """Route the query to retrieval or a normal conversational response."""
    if "search" in query.lower():
        return "RAG"

    return "GENERAL"


def executor_agent(query):
    """Return useful context for the backend; general questions should not use a fake placeholder."""
    task = planner_agent(query)

    shared_memory.append({
        "query": query,
        "task": task,
    })

    if task == "RAG":
        docs = search_documents(query)
        return "\n".join(docs)

    # General questions do not need retrieved context; return an empty string.
    return ""


def governance_agent(response):
    """Validate and apply basic safety checks to the model output."""
    if not validate_output(response):
        return "Invalid response"

    if not guardrails_check(response):
        return "Blocked by governance"

    return response
