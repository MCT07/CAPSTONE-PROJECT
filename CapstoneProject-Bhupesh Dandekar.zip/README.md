# Bhupesh Enterprise AI Assistant

A small FastAPI-based enterprise assistant that combines a simple frontend, a backend API, an orchestrator, and optional Azure AI Search retrieval to answer user questions.

## Project Overview
This project demonstrates a basic AI assistant workflow:
- The frontend sends user messages to the backend.
- The backend calls the orchestrator to decide whether retrieval is needed.
- If retrieval is enabled, the app can query Azure AI Search for relevant context.
- The response passes through simple governance checks before being returned to the user.

## Setup
1. First, add your Azure values into the .env file in the project root. The values should be written there directly, for example:

```text
endpoint=https://your-resource-name.openai.azure.com/
key=your-azure-openai-api-key
deployment=chat-model

search_endpoint=https://your-search-service.search.windows.net
search_key=your-search-admin-key
index_name=your-index-name
```

2. Create and activate a virtual environment:

```python
python -m venv .venv
```

3. Install dependencies:

```python
python -m pip install -r requirements.txt
```

4. Start the backend:

```python
python -m uvicorn backend:app --host 0.0.0.0 --port 8000
```

5. Open index.html in a browser to use the demo UI.

## Notes
- If Azure credentials are not configured yet, the backend will start and return a clear message instead of failing.
- Retrieval only works when Azure AI Search values are present.
- The current governance layer blocks obvious unsafe language such as hack, illegal, attack, or bypass.
