import requests

search_endpoint = "https://genai-searchnave.search.windows.net"
search_key = "mYn9t3OS5v2Gv2slRUJiIqNhPLTwMQhpjYE9BnQGa6AzSeBZFcas"
index_name = "search-1783311972630"

def search_documents(query):


    url = f"{search_endpoint}/indexes/{index_name}/docs/search?api-version=2024-07-01-Preview"

    headers = {
        "Content-Type": "application/json",
        "api-key": search_key
    }

    data = {
        "search": query,
        "top": 3
    }

    response = requests.post(
        url,
        headers=headers,
        json=data
    )

    results = response.json()

    if "value" not in results:
        return []

    return [doc.get("chunk", "") for doc in results["value"]]

