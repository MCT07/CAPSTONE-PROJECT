import os

import backend
import orchestrator


def test_backend_loads_azure_settings_from_env():
    assert backend.endpoint == os.getenv("endpoint")
    assert backend.key == os.getenv("key")
    assert backend.deployment == os.getenv("deployment", "chat-model")


def test_general_queries_do_not_use_placeholder_context():
    result = orchestrator.executor_agent("What is Azure OpenAI?")
    assert result == ""
