# Bhupesh Enterprise AI Assistant

This folder contains the FastAPI-based enterprise AI assistant app.

## Setup
1. Install dependencies: pip install -r requirements.txt
2. Create a local .env file with your Azure credentials.
3. Start the backend: uvicorn backend:app --host 0.0.0.0 --port 8000
4. Open index.html in a browser.
