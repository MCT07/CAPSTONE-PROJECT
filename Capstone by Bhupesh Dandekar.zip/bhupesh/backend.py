import os

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from openai import AzureOpenAI
from pydantic import BaseModel

from orchestrator import executor_agent, governance_agent

# Load environment variables from the local .env file if it exists.
load_dotenv()

app = FastAPI(title="Enterprise AI Assistant")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Read Azure OpenAI settings from environment variables.
endpoint = os.getenv("endpoint", "").strip()
key = os.getenv("key", "").strip()
deployment = os.getenv("deployment", "chat-model").strip()

if not endpoint or not key:
    raise RuntimeError("Azure OpenAI credentials are missing. Check the .env file.")

client = AzureOpenAI(
    api_version="2024-12-01-preview",
    azure_endpoint=endpoint,
    api_key=key,
)


class ChatRequest(BaseModel):
    message: str


@app.post("/chat")
def chat(request: ChatRequest):
    """
    Receive a user message, retrieve context from the orchestrator,
    ask Azure OpenAI for a grounded response, and apply governance checks.
    """
    retrieved_context = executor_agent(request.message)

    # Build a context string. For general questions, there may be no retrieved context.
    context = "\n".join(
        retrieved_context
        if isinstance(retrieved_context, list)
        else [retrieved_context]
    )

    try:
        user_content = request.message
        if context.strip():
            user_content = f"Context:\n{context}\n\nQuestion:\n{request.message}"

        response = client.chat.completions.create(
            model=deployment,
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful enterprise assistant. Answer briefly and directly. Use the provided context when it is relevant, but answer the user's question directly when it is not.",
                },
                {
                    "role": "user",
                    "content": user_content,
                },
            ],
            max_completion_tokens=500,
        )

        answer = response.choices[0].message.content or ""
        final_answer = governance_agent(answer)
    except Exception as exc:
        final_answer = f"Backend error: {exc}"

    return {"response": final_answer}
